import numpy as np
import pmft.pvt.adapter as fl

DISTRS_PVT = [
    "rs",
    "pb",
    "muo",
    "mug",
    "muw",
    "mu_liq",
    "mu_mix",
    "z",
    "bo",
    "bg",
    "bw",
    "rho_oil_rc",
    "rho_gas_rc",
    "rho_wat_rc",
    "rho_liq_rc",
    "rho_mix_rc",
    "compro",
    "q_oil_rc",
    "q_gas_rc",
    "q_wat_rc",
    "q_liq_rc",
    "q_mix_rc",
    "gas_fraction",
    "st_oil_gas",
    "st_wat_gas",
    "st_liq_gas",
]

def extract_output_fluid(fluid: fl.FluidFlow) -> np.ndarray:
    output_array = np.empty(len(DISTRS_PVT))
    output_array[0] = fluid.rs
    output_array[1] = fluid.pb
    output_array[2] = fluid.muo
    output_array[3] = fluid.mug
    output_array[4] = fluid.muw
    output_array[5] = fluid.mul
    output_array[6] = fluid.mum
    output_array[7] = fluid.z
    output_array[8] = fluid.bo
    output_array[9] = fluid.bg
    output_array[10] = fluid.bw
    output_array[11] = fluid.ro
    output_array[12] = fluid.rg
    output_array[13] = fluid.rw
    output_array[14] = fluid.rl
    output_array[15] = fluid.rm
    output_array[16] = fluid.co
    output_array[17] = fluid.qo
    output_array[18] = fluid.qg
    output_array[19] = fluid.qw
    output_array[20] = fluid.ql
    output_array[21] = fluid.qm
    output_array[22] = fluid.gf
    output_array[23] = fluid.stog
    output_array[24] = fluid.stwg
    output_array[25] = fluid.stlg
    return output_array

def check_nan(distr_dict: dict) -> dict:
    for k in distr_dict:
        if all(np.isnan(distr_dict[k])):
            distr_dict[k] = None

    return distr_dict


def make_output_attrs(
        fluid: fl.FluidFlow, p_array: np.ndarray, t_array: np.ndarray
) -> dict:
    result_data = np.empty([len(DISTRS_PVT), len(p_array)])

    for i, p in enumerate(p_array):
        fluid.calc_flow(p, t_array[i])
        result_data[:, i] = extract_output_fluid(fluid)

    result = {k: result_data[i] for i, k in enumerate(DISTRS_PVT)}

    result = check_nan(result)

    return result
