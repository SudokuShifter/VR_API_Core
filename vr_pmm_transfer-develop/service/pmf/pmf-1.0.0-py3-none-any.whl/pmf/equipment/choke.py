import math
from copy import deepcopy
from typing import Optional

import pmf.tools.exceptions as exc
import pmft.pvt.adapter as fl
import scipy.optimize as opt

CP_CV = 1.26

class Choke:
    def __init__(
        self,
        h_mes: float,
        d: float,
        d_up: float,
        fluid: fl.FluidFlow,
    ):
        self.h_mes = h_mes
        self._d_up = d_up
        self.d = d

        self.s_bean = math.pi * d**2.0 / 4.0
        self.fluid = deepcopy(fluid)
        self.c_choke = 0.6
        self.c_vg = None
        self.c_vl = None
        self.z_l = 1.0
        self.extra_dp = 0.0
        self.dp = None

    @property
    def d(self):
        return self._d

    @d.setter
    def d(self, value):
        self._d = value
        self.d_ratio = value

    @property
    def d_ratio(self):
        return self._d_ratio

    @d_ratio.setter
    def d_ratio(self, value):
        self._d_ratio = value / self._d_up
        if self._d_ratio >= 1:
            raise exc.PmfPyError(
                f"Внимание: d штуцера {value} >= d трубы {self._d_up} - невозможено рассчитать."
            )

    def __calc_dp_m(self, fluid_velocity: float, rho_mix: float, gf: float, z: float) -> float:
        dp = (rho_mix * (fluid_velocity**2.0) / 2.0) * (
            ((1.0 - gf) / ((self.c_vl * self.z_l) ** 2.0)) + (gf / ((self.c_vg * z) ** 2.0))
        )
        return dp

    def __calc_q_m(self, dp: float, rho_mix: float, gf: float, z: float) -> float:
        wct = self.fluid.wct
        oil_frac = 1 - wct
        q_mix = self.s_bean * math.sqrt(
            (2.0 * dp) / (rho_mix * (((1.0 - gf) / ((self.c_vl * self.z_l) ** 2.0)) + (gf / ((self.c_vg * z) ** 2.0))))
        )

        if self.fluid.phase_ratio["type"].lower() == "gor":
            q_liq = q_mix / (
                oil_frac * self.fluid.bo
                + self.fluid.bg * (oil_frac * self.fluid.rp - oil_frac * self.fluid.rs)
                + wct * self.fluid.bw
            )
        else:
            q_liq = q_mix / (
                oil_frac * self.fluid.bo
                + self.fluid.bg * (self.fluid.rp - oil_frac * self.fluid.rs)
                + wct * self.fluid.bw
            )

        return q_liq

    def __calc_dp(
        self,
        fluid_velocity: float,
        rho_mix: float,
        gf: float,
        z: float,
        c_choke: Optional[float] = None,
    ) -> float:
        self.__calc_choke_cal(c_choke)
        return self.__calc_dp_m(fluid_velocity, rho_mix, gf, z)

    def __calc_q(
        self,
        dp: float,
        rho_mix: float,
        gf: float,
        z: float,
        c_choke: Optional[float] = None,
    ) -> float:
        self.__calc_choke_cal(c_choke)
        return self.__calc_q_m(dp, rho_mix, gf, z)

    def __calc_choke_cal(
        self,
        c_choke: Optional[float] = None
    ):
        self.c_vg, self.c_vl = 1.3, 1.3
        if c_choke is not None:
            self.c_choke = c_choke
        d_den = 1.0 - self.d_ratio**4
        if d_den > 0:
            c_v = self.c_choke / math.sqrt(d_den)
            self.c_vl, self.c_vg = c_v, c_v

    @staticmethod
    def __set_rt(current_param: float, critical_param: float) -> str:
        if abs(current_param - critical_param) < 0.01:
            return "critical"
        if current_param > critical_param:
            return "supercritical"
        return "subcritical"

    def __calc_sv(
        self,
        p_out: float,
        gas_density: float,
        gf: float,
        wf: float
    ) -> float:
        if gf == 0:
            sonic_velocity = (1.0 - wf) * 1323.7464 + wf * 1492.6056
        else:
            sonic_velocity = math.sqrt(CP_CV * p_out / gas_density)

        return sonic_velocity

    def __calc_cve(
        self,
        p_crit: float,
        t_crit: float,
        sonic_vel: float) -> float:
        self.fluid.calc_flow(p_crit, t_crit)
        fluid_vel = self.fluid.qm / self.s_bean
        return fluid_vel - sonic_vel

    def calc_qliq(
        self,
        p_in: float,
        t_in: float,
        p_out: float,
        t_out: float,
        wct: Optional[float] = None,
        phase_ratio_value: Optional[float] = None,
        c_choke: Optional[float] = None,
        explicit: bool = False,
    ) -> float:
        if wct is not None:
            self.fluid.reinit_wct(wct)

        if phase_ratio_value is not None:
            fluid_t = deepcopy(self.fluid)
            pvt_data = fluid_t.pvt_model_data
            phase_ratio = pvt_data["black_oil"]["phase_ratio"]
            phase_ratio.update({"value": phase_ratio_value})
            self.fluid.reinit_phase_ratio(phase_ratio)

        if p_in > p_out:
            return self.__calc_qliq(p_in, t_in, p_out, t_out, c_choke, explicit)

        raise exc.PmfPyError(
            f"Внимание: P на входе, {p_in} <= P на выходе, {p_out} - невозможено рассчитать."
        )

    def __calc_qliq(
        self,
        p_in: float,
        t_in: float,
        p_out: float,
        t_out: float,
        c_choke: Optional[float] = None,
        explicit: bool = False,
    ) -> float:
        if explicit:
            p, t = p_in, t_in
        else:
            p, t = p_out, t_out

        self.fluid.calc_flow(p, t)
        wct = self.fluid.wct
        oil_frac = 1 - wct

        rs = self.fluid.rs
        bg = self.fluid.bg
        bo = self.fluid.bo
        bw = self.fluid.bw

        if self.fluid.phase_ratio["type"].lower() == "gor":
            fg = bg * oil_frac * (self.fluid.rp - rs)
        else:
            fg = bg * (self.fluid.rp - rs * oil_frac)

        fo = oil_frac * bo
        fw = wct * bw
        fm = fg + fo + fw
        gf = fg / fm

        sonic_velocity = self.__calc_sv(p_out, self.fluid.rg, gf, self.fluid.wf)
        z = 1 - ((0.41 + 0.35 * self.d_ratio**4.0) / CP_CV) * ((p_in - p_out) / p_in)

        if explicit:
            rho_mix = (fo * self.fluid.ro + fg * self.fluid.rg + fw * self.fluid.rw) / fm
            return self.__calc_q(p_in - p_out, rho_mix, gf, z, c_choke)

        q_liq = opt.brentq(
            self.__calc_dpe,
            a=0.00001,
            b=10,
            args=(p_in, t_in, p_out, t_out, sonic_velocity, z, c_choke),
        )
        return q_liq

    def __calc_dpe(
        self,
        q_iter: float,
        p_in: float,
        t_in: float,
        p_out: float,
        t_out: float,
        sonic_velocity: float,
        z: float,
        c_choke: float,
    ) -> float:
        self.extra_dp = 0

        self.fluid.q_fluid = q_iter
        self.fluid.reinit_q_fluid(q_iter)

        self.fluid.calc_flow(p_out, t_out)
        fluid_velocity_out = self.fluid.qm / self.s_bean
        regime_type = self.__set_rt(fluid_velocity_out, sonic_velocity)

        try:
            self.p_crit = opt.brentq(self.__calc_cve, a=1, b=10000000000, args=(t_out, sonic_velocity))
        except ValueError:
            self.p_crit = opt.minimize_scalar(
                self.__calc_cve,
                p_out,
                args=(t_out, sonic_velocity),
                bounds=(p_out, p_in),
                method="bounded",
            ).x
        self.fluid.calc_flow(p_in, t_in)
        fluid_velocity = self.fluid.qm / self.s_bean

        if regime_type == "supercritical":
            regime_type = "critical"
            z = 1 - ((0.41 + 0.35 * self.d_ratio**4.0) / CP_CV) * ((p_in - self.p_crit) / p_in)
            self.extra_dp = self.p_crit - p_out

        self.dp = self.__calc_dp(fluid_velocity, self.fluid.rm, self.fluid.gf, z, c_choke)

        return self.dp + self.extra_dp - (p_in - p_out)
